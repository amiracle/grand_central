Usage:

1. Create a directory with all credential(-n).json files

2. `python credential_smusher.py {relative or absolute path of directory containing credential files}`

3. Collapsed credential file created by the script is name all_account_credentials.json